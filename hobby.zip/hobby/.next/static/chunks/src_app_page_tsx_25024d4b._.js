(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_25024d4b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_25024d4b._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_98ce380f._.js",
    "static/chunks/src_e6e9be9f._.js",
    "static/chunks/node_modules_next_8b9ab939._.js"
  ],
  "source": "dynamic"
});
