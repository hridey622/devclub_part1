(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_auth_onboarding_notification-preferences_page_tsx_25024d4b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_auth_onboarding_notification-preferences_page_tsx_25024d4b._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d4eecfd3._.js",
    "static/chunks/_f41933e2._.js"
  ],
  "source": "dynamic"
});
