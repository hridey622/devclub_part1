'use client';

import { useEffect, useState, useCallback } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

interface Player {
  id: number;
  name: string;
  age: number;
  distance: string;
  location?: {
    lat: number;
    lng: number;
  };
  skillLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  availability: string[];
  rating: number;
  sports?: string[];
}

// Get coordinates from URL parameters or use default if not available
const getLocationFromUrl = () => {
  if (typeof window !== 'undefined') {
    const urlParams = new URLSearchParams(window.location.search);
    const lat = parseFloat(urlParams.get('lat') || '0');
    const lng = parseFloat(urlParams.get('lng') || '0');
    return { lat, lng };
  }
  return { lat: 0, lng: 0 };
};

// Calculate distance between two points using Haversine formula
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  const d = R * c; // Distance in km
  return d;
};

// Sample mock data for different sports with location coordinates
const MOCK_PLAYERS: Record<string, Player[]> = {
  'cricket': [
    { id: 1, name: 'Rahul Kumar', age: 28, distance: '0.8 km', location: { lat: 28.6139, lng: 77.2090 }, skillLevel: 'Intermediate' as const, availability: ['Weekends', 'Friday evenings'], rating: 4.5, sports: ['Cricket', 'Football'] },
    { id: 2, name: 'Priya Singh', age: 24, distance: '1.2 km', location: { lat: 28.6223, lng: 77.2087 }, skillLevel: 'Advanced' as const, availability: ['Monday', 'Wednesday'], rating: 4.8, sports: ['Cricket'] },
    { id: 3, name: 'Amit Patel', age: 31, distance: '2.5 km', location: { lat: 28.6263, lng: 77.2219 }, skillLevel: 'Intermediate' as const, availability: ['Weekends'], rating: 4.3, sports: ['Cricket', 'Badminton'] },
    { id: 4, name: 'Vikram Malhotra', age: 27, distance: '3.1 km', location: { lat: 28.6307, lng: 77.2257 }, skillLevel: 'Beginner' as const, availability: ['Tuesday', 'Thursday'], rating: 4.0, sports: ['Cricket'] },
    { id: 5, name: 'Sneha Gupta', age: 29, distance: '3.8 km', location: { lat: 28.6129, lng: 77.2295 }, skillLevel: 'Advanced' as const, availability: ['Weekdays'], rating: 4.7, sports: ['Cricket', 'Tennis'] },
  ],
  'football': [
    { id: 1, name: 'Raj Sharma', age: 26, distance: '1.5 km', location: { lat: 28.6159, lng: 77.2115 }, skillLevel: 'Intermediate' as const, availability: ['Weekends'], rating: 4.2, sports: ['Football', 'Cricket'] },
    { id: 2, name: 'Arjun Singh', age: 22, distance: '2.2 km', location: { lat: 28.6197, lng: 77.2039 }, skillLevel: 'Advanced' as const, availability: ['Evenings'], rating: 4.9, sports: ['Football'] },
    { id: 3, name: 'Divya Chauhan', age: 28, distance: '2.8 km', location: { lat: 28.6083, lng: 77.2022 }, skillLevel: 'Beginner' as const, availability: ['Weekends'], rating: 3.8, sports: ['Football', 'Tennis'] },
    { id: 4, name: 'Karan Mehta', age: 30, distance: '3.2 km', location: { lat: 28.6050, lng: 77.2165 }, skillLevel: 'Intermediate' as const, availability: ['Monday', 'Wednesday'], rating: 4.1, sports: ['Football', 'Badminton'] },
  ],
  'badminton': [
    { id: 1, name: 'Neha Reddy', age: 25, distance: '0.5 km', location: { lat: 28.6125, lng: 77.2091 }, skillLevel: 'Intermediate' as const, availability: ['Evenings'], rating: 4.3, sports: ['Badminton', 'Tennis'] },
    { id: 2, name: 'Anil Kumar', age: 33, distance: '1.8 km', location: { lat: 28.6186, lng: 77.2145 }, skillLevel: 'Advanced' as const, availability: ['Weekends'], rating: 4.7, sports: ['Badminton'] },
    { id: 3, name: 'Meera Joshi', age: 29, distance: '2.3 km', location: { lat: 28.6202, lng: 77.1987 }, skillLevel: 'Beginner' as const, availability: ['Tuesday', 'Thursday'], rating: 3.9, sports: ['Badminton', 'Cricket'] },
  ],
  'tennis': [
    { id: 1, name: 'Rohan Kapoor', age: 31, distance: '1.2 km', location: { lat: 28.6153, lng: 77.2136 }, skillLevel: 'Advanced' as const, availability: ['Weekends'], rating: 4.8, sports: ['Tennis'] },
    { id: 2, name: 'Anjali Desai', age: 27, distance: '2.4 km', location: { lat: 28.6093, lng: 77.2211 }, skillLevel: 'Intermediate' as const, availability: ['Monday', 'Wednesday', 'Friday'], rating: 4.2, sports: ['Tennis', 'Badminton'] },
  ],
};

export default function PlayerListPage() {
  const params = useParams();
  const sport = params.sport as string;
  const [players, setPlayers] = useState<Player[]>([]);
  const [filterSkill, setFilterSkill] = useState<string>('all');
  const [filterDistance, setFilterDistance] = useState<string>('all');
  const [filterMultisport, setFilterMultisport] = useState<boolean>(false);
  const [userLocation, setUserLocation] = useState({ lat: 0, lng: 0 });
  const [isLoading, setIsLoading] = useState(true);

  // Format sport name for display
  const formatSportName = (sportSlug: string) => {
    return sportSlug.charAt(0).toUpperCase() + sportSlug.slice(1);
  };

  // Calculate real distances based on user's location
  const updatePlayerDistances = useCallback((playersData: Player[], userLoc: { lat: number, lng: number }) => {
    return playersData.map(player => {
      if (player.location) {
        const distanceKm = calculateDistance(
          userLoc.lat, 
          userLoc.lng, 
          player.location.lat, 
          player.location.lng
        );
        return {
          ...player,
          distance: `${distanceKm.toFixed(1)} km`
        };
      }
      return player;
    });
  }, []);

  // Load players data and simulate fetching from API
  useEffect(() => {
    setIsLoading(true);
    
    // Get user location from URL parameters
    const locationFromUrl = getLocationFromUrl();
    setUserLocation(locationFromUrl);
    
    // Simulate API call delay
    setTimeout(() => {
      const sportData = MOCK_PLAYERS[sport as keyof typeof MOCK_PLAYERS] || [];
      const playersWithRealDistances = updatePlayerDistances(sportData, locationFromUrl);
      setPlayers(playersWithRealDistances);
      setIsLoading(false);
    }, 1000);
  }, [sport, updatePlayerDistances]);

  // Filter players based on selected filters
  const filteredPlayers = players.filter(player => {
    // Filter by skill level
    if (filterSkill !== 'all' && player.skillLevel !== filterSkill) {
      return false;
    }
    
    // Filter by distance
    if (filterDistance !== 'all') {
      const kmDistance = parseFloat(player.distance.split(' ')[0]);
      const maxDistance = parseFloat(filterDistance.split(' ')[0]);
      if (kmDistance > maxDistance) {
        return false;
      }
    }
    
    // Filter by multi-sport interest (players who play more than one sport including the current one)
    if (filterMultisport && player.sports) {
      // Only show players who play multiple sports including the current one
      const formattedSport = formatSportName(sport);
      return player.sports.includes(formattedSport) && player.sports.length > 1;
    }
    
    return true;
  });

  return (
    <>
      <Header />
      
      <main className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 py-10">
        <div className="container-custom">
          {/* Page Header */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 mb-8">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <h1 className="heading-lg text-gray-900 dark:text-white mb-2">
                  {formatSportName(sport)} Players Near You
                </h1>
                <p className="text-gray-600 dark:text-gray-300">
                  Find and connect with {formatSportName(sport)} players in your area
                </p>
              </div>
              <Link 
                href="/"
                className="btn-secondary flex items-center"
              >
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Change Sport
              </Link>
            </div>
          </div>

          {/* Filters and Results Section */}
          <div className="grid md:grid-cols-4 gap-8">
            {/* Filters Sidebar */}
            <div className="md:col-span-1">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 sticky top-20">
                <h2 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Filters</h2>
                
                {/* Skill Level Filter */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Skill Level
                  </label>
                  <select
                    value={filterSkill}
                    onChange={(e) => setFilterSkill(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="all">All Levels</option>
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
                
                {/* Distance Filter */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Distance
                  </label>
                  <select
                    value={filterDistance}
                    onChange={(e) => setFilterDistance(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                  >
                    <option value="all">Any Distance</option>
                    <option value="1 km">Within 1 km</option>
                    <option value="2 km">Within 2 km</option>
                    <option value="5 km">Within 5 km</option>
                    <option value="10 km">Within 10 km</option>
                  </select>
                </div>
                
                {/* Availability Filter (Simplified) */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Availability
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
                      <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Weekdays</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
                      <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Weekends</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
                      <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Evenings</span>
                    </label>
                  </div>
                </div>
                
                {/* Multi-sport interest filter */}
                <div>
                  <label className="flex items-center">
                    <input 
                      type="checkbox" 
                      checked={filterMultisport}
                      onChange={e => setFilterMultisport(e.target.checked)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" 
                    />
                    <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                      Players with similar interests
                    </span>
                  </label>
                  <p className="text-xs text-gray-500 mt-1 ml-6">
                    Find players who also play other sports
                  </p>
                </div>
              </div>
            </div>
            
            {/* Player Results */}
            <div className="md:col-span-3">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="flex flex-col items-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
                    <p className="text-gray-600 dark:text-gray-300">Loading players...</p>
                  </div>
                </div>
              ) : filteredPlayers.length > 0 ? (
                <div className="space-y-4">
                  {filteredPlayers.map(player => (
                    <div
                      key={player.id}
                      className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-full flex-shrink-0 flex items-center justify-center">
                          <svg className="w-8 h-8 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                          </svg>
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{player.name}</h3>
                              <p className="text-gray-600 dark:text-gray-400 text-sm">{player.age} years • {player.distance}</p>
                            </div>
                            <div className="flex items-center">
                              <span className="text-yellow-500 mr-1">
                                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                              </span>
                              <span className="font-medium text-gray-900 dark:text-white">{player.rating}</span>
                            </div>
                          </div>
                          <div className="mt-2">
                            <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mr-2 ${
                              player.skillLevel === 'Beginner' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' :
                              player.skillLevel === 'Intermediate' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' :
                              'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300'
                            }`}>
                              {player.skillLevel}
                            </span>
                            {player.availability.map((time, index) => (
                              <span key={index} className="inline-block px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300 rounded-full text-xs font-medium mr-2">
                                {time}
                              </span>
                            ))}
                            
                            {/* Show other sports the player plays */}
                            {player.sports && player.sports.length > 1 && (
                              <div className="mt-1">
                                <span className="text-xs text-gray-500 dark:text-gray-400">Also plays: </span>
                                {player.sports
                                  .filter(s => s.toLowerCase() !== sport)
                                  .map((s, i) => (
                                    <span key={i} className="inline-block px-2 py-1 bg-blue-50 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full text-xs font-medium mr-1">
                                      {s}
                                    </span>
                                  ))
                                }
                              </div>
                            )}
                          </div>
                        </div>
                        <div>
                          <button className="btn-primary py-2 px-4 text-sm">Message</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 text-center">
                  <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No players found</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    No {formatSportName(sport)} players match your current filters. Try adjusting your filters or check back later.
                  </p>
                  <button 
                    onClick={() => {
                      setFilterSkill('all');
                      setFilterDistance('all');
                    }}
                    className="text-blue-600 hover:text-blue-800 dark:text-blue-400 font-medium"
                  >
                    Clear filters
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}
