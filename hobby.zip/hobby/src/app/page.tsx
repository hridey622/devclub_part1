'use client';

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Home() {
  const router = useRouter();
  const [selectedSport, setSelectedSport] = useState<string | null>(null);
  const [showLocationPrompt, setShowLocationPrompt] = useState(false);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);

  const handleSportSelect = (sport: string) => {
    setSelectedSport(sport);
  };

  const handleFindPlayers = () => {
    if (selectedSport) {
      setShowLocationPrompt(true);
    }
  };

  const handleAllowLocation = () => {
    setIsDetectingLocation(true);
    
    // Use the browser's geolocation API to get user coordinates
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          
          // Redirect with coordinates as query parameters
          if (selectedSport) {
            router.push(`/players/${selectedSport.toLowerCase()}?lat=${latitude}&lng=${longitude}`);
          }
        },
        (error) => {
          console.error("Error getting location:", error);
          // Fall back to default coordinates (center of Delhi) if there's an error
          if (selectedSport) {
            // Default coordinates (example: Delhi, India)
            router.push(`/players/${selectedSport.toLowerCase()}?lat=28.6139&lng=77.2090`);
          }
        },
        { timeout: 5000, enableHighAccuracy: true }
      );
    } else {
      // Browser doesn't support geolocation
      if (selectedSport) {
        router.push(`/players/${selectedSport.toLowerCase()}`);
      }
      setIsDetectingLocation(false);
    }
  };

  const handleDenyLocation = () => {
    // Redirect without location data - will use default values in the players page
    if (selectedSport) {
      router.push(`/players/${selectedSport.toLowerCase()}`);
    }
  };

  return (
    <>
      <Header />
      
      <main className="flex flex-col min-h-screen">
        {/* Hero Section - Centered with Sports Selection */}
        <section className="relative bg-blue-50 dark:bg-gray-900 py-20 md:py-32">
          <div className="container-custom">
            {/* Central Content */}
            <div className="text-center max-w-3xl mx-auto mb-16 relative z-10">
              <h1 className="heading-xl text-blue-600 mb-6">
                Find Your Game, Find Your Crew
              </h1>
              <p className="text-xl text-gray-700 dark:text-gray-300 mb-10">
                Hobby connects you with players, professionals, and sports venues in your area. 
                Join games, improve your skills, and be part of a community.
              </p>
            </div>
            
            {/* Instructions */}
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Select Your Sport</h2>
              <p className="text-gray-600 dark:text-gray-300">
                Choose a sport below and find players in your area
              </p>
            </div>
            
            {/* Sports Selection Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 max-w-5xl mx-auto mb-12">
              {/* Cricket */}
              <button 
                onClick={() => handleSportSelect('Cricket')}
                className={`group relative focus:outline-none ${
                  selectedSport === 'Cricket' ? 'ring-4 ring-blue-500 dark:ring-blue-400' : ''
                }`}
              >
                <div className="relative w-full pt-[100%] overflow-hidden rounded-2xl transform transition-transform group-hover:scale-105">
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70 z-10"></div>
                  <div className="absolute inset-0">
                    <Image
                      src="/images/cricket.png"
                      alt="Cricket"
                      fill
                      style={{ objectFit: 'cover' }}
                      className="rounded-2xl"
                    />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center z-20">
                    <h3 className="text-2xl font-bold text-white">Cricket</h3>
                  </div>
                  {selectedSport === 'Cricket' && (
                    <div className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center z-30">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </div>
              </button>

              {/* Football */}
              <button 
                onClick={() => handleSportSelect('Football')}
                className={`group relative focus:outline-none ${
                  selectedSport === 'Football' ? 'ring-4 ring-blue-500 dark:ring-blue-400' : ''
                }`}
              >
                <div className="relative w-full pt-[100%] overflow-hidden rounded-2xl transform transition-transform group-hover:scale-105">
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70 z-10"></div>
                  <div className="absolute inset-0">
                    <Image
                      src="/images/football.png"
                      alt="Football"
                      fill
                      style={{ objectFit: 'cover' }}
                      className="rounded-2xl"
                    />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center z-20">
                    <h3 className="text-2xl font-bold text-white">Football</h3>
                  </div>
                  {selectedSport === 'Football' && (
                    <div className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center z-30">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </div>
              </button>

              {/* Badminton */}
              <button 
                onClick={() => handleSportSelect('Badminton')}
                className={`group relative focus:outline-none ${
                  selectedSport === 'Badminton' ? 'ring-4 ring-blue-500 dark:ring-blue-400' : ''
                }`}
              >
                <div className="relative w-full pt-[100%] overflow-hidden rounded-2xl transform transition-transform group-hover:scale-105">
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70 z-10"></div>
                  <div className="absolute inset-0">
                    <Image
                      src="/images/badminton.jpg"
                      alt="Badminton"
                      fill
                      style={{ objectFit: 'cover' }}
                      className="rounded-2xl"
                    />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center z-20">
                    <h3 className="text-2xl font-bold text-white">Badminton</h3>
                  </div>
                  {selectedSport === 'Badminton' && (
                    <div className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center z-30">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </div>
              </button>

              {/* Tennis (Placeholder) */}
              <button 
                onClick={() => handleSportSelect('Tennis')}
                className={`group relative focus:outline-none ${
                  selectedSport === 'Tennis' ? 'ring-4 ring-blue-500 dark:ring-blue-400' : ''
                }`}
              >
                <div className="relative w-full pt-[100%] overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 transform transition-transform group-hover:scale-105">
                  <div className="absolute inset-0 flex items-center justify-center z-20">
                    <h3 className="text-2xl font-bold text-white">Tennis</h3>
                  </div>
                  {selectedSport === 'Tennis' && (
                    <div className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center z-30">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </div>
              </button>
            </div>
            
            {/* Find Players Button */}
            <div className="text-center">
              <button
                onClick={handleFindPlayers}
                disabled={!selectedSport}
                className={`btn-primary py-3 px-10 inline-flex items-center ${
                  !selectedSport ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                Find Players
              </button>
              
              {!selectedSport && (
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  Please select a sport first
                </p>
              )}
            </div>
            
            {/* Location Permission Dialog */}
            {showLocationPrompt && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-white dark:bg-gray-800 rounded-xl p-6 md:p-8 max-w-md w-full">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg className="w-8 h-8 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      Share Your Location
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-6">
                      To find players near you for {selectedSport}, we need access to your location.
                    </p>
                  </div>
                  
                  <div className="space-y-3">
                    <button
                      onClick={handleAllowLocation}
                      disabled={isDetectingLocation}
                      className="w-full btn-primary py-3 flex justify-center items-center"
                    >
                      {isDetectingLocation ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Detecting Location...
                        </>
                      ) : (
                        <>Allow Location Access</>
                      )}
                    </button>
                    
                    <button
                      onClick={handleDenyLocation}
                      disabled={isDetectingLocation}
                      className="w-full border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-medium rounded-full py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    >
                      Skip
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* How It Works */}
        <section id="how-it-works" className="py-20 bg-white dark:bg-gray-800">
          <div className="container-custom">
            <div className="text-center mb-16">
              <h2 className="heading-lg mb-4">How It Works</h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
                Getting started with Hobby is easy and takes only a few minutes
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-8">
              {/* Step 1 */}
              <div className="relative">
                <div className="card relative z-10">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600 font-bold text-xl mb-6">
                    1
                  </div>
                  <h3 className="text-xl font-bold mb-3">Select Sport</h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Choose your favorite sport to play
                  </p>
                </div>
                {/* Connector */}
                <div className="hidden md:block absolute top-10 left-full w-full h-0.5 bg-blue-200 dark:bg-blue-800 z-0"></div>
              </div>

              {/* Step 2 */}
              <div className="relative">
                <div className="card relative z-10">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600 font-bold text-xl mb-6">
                    2
                  </div>
                  <h3 className="text-xl font-bold mb-3">Find Players</h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Discover players near you with similar interests
                  </p>
                </div>
                {/* Connector */}
                <div className="hidden md:block absolute top-10 left-full w-full h-0.5 bg-blue-200 dark:bg-blue-800 z-0"></div>
              </div>

              {/* Step 3 */}
              <div className="relative">
                <div className="card relative z-10">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600 font-bold text-xl mb-6">
                    3
                  </div>
                  <h3 className="text-xl font-bold mb-3">Connect</h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Message and arrange to meet at a venue
                  </p>
                </div>
                {/* Connector */}
                <div className="hidden md:block absolute top-10 left-full w-full h-0.5 bg-blue-200 dark:bg-blue-800 z-0"></div>
              </div>

              {/* Step 4 */}
              <div>
                <div className="card">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600 font-bold text-xl mb-6">
                    4
                  </div>
                  <h3 className="text-xl font-bold mb-3">Play</h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Enjoy your games and track your progress
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-blue-600 text-white">
          <div className="container-custom text-center">
            <h2 className="heading-lg mb-6">Ready to Find Your Game?</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Join Hobby today and connect with players, find venues, and get into the game!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/auth/signup" className="bg-white text-blue-600 hover:bg-gray-100 font-semibold py-3 px-8 rounded-full transition-colors text-center">
                Sign Up Free
              </Link>
              <Link href="/auth/login" className="bg-blue-500 hover:bg-blue-700 text-white border border-white font-semibold py-3 px-8 rounded-full transition-colors text-center">
                Log In
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
