'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';

// Define the sports available in the app
const AVAILABLE_SPORTS = [
  { id: 'cricket', name: 'Cricket' },
  { id: 'football', name: 'Football' },
  { id: 'tennis', name: 'Tennis' },
  { id: 'badminton', name: 'Badminton' },
  { id: 'pickleball', name: 'Pickleball' },
  { id: 'basketball', name: 'Basketball' },
  { id: 'volleyball', name: 'Volleyball' },
  { id: 'table-tennis', name: 'Table Tennis' }
];

// Define skill levels
const SKILL_LEVELS = [
  { id: 'beginner', name: 'Beginner', description: 'New to the sport or play occasionally' },
  { id: 'intermediate', name: 'Intermediate', description: 'Play regularly with decent skills' },
  { id: 'advanced', name: 'Advanced', description: 'Very experienced with strong skills' }
];

interface SelectedSport {
  id: string;
  skillLevel: string;
}

export default function OnboardingSportsSkills() {
  const router = useRouter();
  const [fitnessLevel, setFitnessLevel] = useState('');
  const [selectedSports, setSelectedSports] = useState<SelectedSport[]>([]);
  const [currentSport, setCurrentSport] = useState('');
  const [currentSkillLevel, setCurrentSkillLevel] = useState('');
  const [errors, setErrors] = useState({
    fitnessLevel: '',
    sports: ''
  });

  const handleFitnessLevelChange = (level: string) => {
    setFitnessLevel(level);
    if (errors.fitnessLevel) {
      setErrors(prev => ({ ...prev, fitnessLevel: '' }));
    }
  };

  const handleSportSelect = (sportId: string) => {
    setCurrentSport(sportId);
    setCurrentSkillLevel('');
  };

  const handleSkillLevelSelect = (level: string) => {
    setCurrentSkillLevel(level);
    
    // Add/update the sport and skill level in selectedSports
    const sportExists = selectedSports.some(sport => sport.id === currentSport);
    
    if (sportExists) {
      setSelectedSports(selectedSports.map(sport => 
        sport.id === currentSport ? { ...sport, skillLevel: level } : sport
      ));
    } else {
      setSelectedSports([...selectedSports, { id: currentSport, skillLevel: level }]);
    }
    
    // Clear sports error if it exists
    if (errors.sports) {
      setErrors(prev => ({ ...prev, sports: '' }));
    }
    
    // Reset current sport selection after adding
    setCurrentSport('');
  };

  const removeSport = (sportId: string) => {
    setSelectedSports(selectedSports.filter(sport => sport.id !== sportId));
  };

  const getSportName = (sportId: string) => {
    return AVAILABLE_SPORTS.find(sport => sport.id === sportId)?.name || sportId;
  };
  
  const getSkillLevelName = (levelId: string) => {
    return SKILL_LEVELS.find(level => level.id === levelId)?.name || levelId;
  };

  const handleBack = () => {
    router.push('/auth/onboarding/location');
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = { ...errors };

    if (!fitnessLevel) {
      newErrors.fitnessLevel = 'Please select your fitness level';
      isValid = false;
    }

    if (selectedSports.length === 0) {
      newErrors.sports = 'Please select at least one sport and skill level';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleContinue = () => {
    if (!validateForm()) return;
    
    // In a real app, you would store the sports/skills data
    // For demo purposes, we'll just proceed to the next step
    router.push('/auth/onboarding/notification-preferences');
  };

  return (
    <>
      <Header />
      <main className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container-custom max-w-xl mx-auto">
          <div className="card">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex justify-between items-center">
                <div className="flex-1">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '80%' }}></div>
                  </div>
                </div>
                <span className="ml-4 text-sm text-gray-600 dark:text-gray-400">Step 4 of 5</span>
              </div>
            </div>
            
            <div className="text-center mb-8">
              <h1 className="heading-lg text-gray-900 dark:text-white mb-2">Fitness & Skills</h1>
              <p className="text-gray-600 dark:text-gray-300">
                Tell us about your sports interests and skill levels
              </p>
            </div>

            <div className="space-y-10">
              {/* Fitness Level Section */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  What's your overall fitness level?
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {['Beginner', 'Intermediate', 'Advanced'].map((level) => (
                    <button
                      key={level.toLowerCase()}
                      type="button"
                      onClick={() => handleFitnessLevelChange(level.toLowerCase())}
                      className={`p-4 rounded-lg border-2 text-center transition-colors
                        ${fitnessLevel === level.toLowerCase()
                          ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                          : 'border-gray-200 dark:border-gray-700 hover:border-blue-200 dark:hover:border-blue-800'
                        }`}
                    >
                      <span className="block font-medium text-lg mb-1">{level}</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {level === 'Beginner' && 'New to exercise or occasional activity'}
                        {level === 'Intermediate' && 'Regular exercise with moderate intensity'}
                        {level === 'Advanced' && 'Frequent high-intensity workouts'}
                      </span>
                    </button>
                  ))}
                </div>
                {errors.fitnessLevel && (
                  <p className="mt-2 text-sm text-red-600">{errors.fitnessLevel}</p>
                )}
              </div>

              {/* Sports & Skill Levels Section */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  What sports are you interested in?
                </h2>
                
                {/* Selected Sports List */}
                {selectedSports.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Your Selected Sports:
                    </h3>
                    <div className="space-y-2">
                      {selectedSports.map((sport) => (
                        <div 
                          key={sport.id}
                          className="flex items-center justify-between bg-gray-50 dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700"
                        >
                          <div>
                            <span className="font-medium">{getSportName(sport.id)}</span>
                            <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                              {getSkillLevelName(sport.skillLevel)}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeSport(sport.id)}
                            className="text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-400"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Add New Sport */}
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                  {!currentSport ? (
                    <div className="p-4">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Add a sport:
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {AVAILABLE_SPORTS.map((sport) => {
                          const isSelected = selectedSports.some(s => s.id === sport.id);
                          return (
                            <button
                              key={sport.id}
                              type="button"
                              onClick={() => handleSportSelect(sport.id)}
                              disabled={isSelected}
                              className={`p-2 rounded text-center text-sm
                                ${isSelected
                                  ? 'bg-gray-100 dark:bg-gray-700 text-gray-400 dark:text-gray-500 cursor-not-allowed'
                                  : 'bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 border border-gray-200 dark:border-gray-700'
                                }`}
                            >
                              {sport.name}
                              {isSelected && ' ✓'}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-medium">
                          {getSportName(currentSport)} - Select Skill Level
                        </h3>
                        <button
                          type="button"
                          onClick={() => setCurrentSport('')}
                          className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                      <div className="space-y-2">
                        {SKILL_LEVELS.map((level) => (
                          <button
                            key={level.id}
                            type="button"
                            onClick={() => handleSkillLevelSelect(level.id)}
                            className="w-full text-left p-3 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-blue-50 dark:hover:bg-blue-900/20"
                          >
                            <div className="font-medium">{level.name}</div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">{level.description}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                {errors.sports && (
                  <p className="mt-2 text-sm text-red-600">{errors.sports}</p>
                )}
              </div>

              <div className="flex space-x-4 pt-6">
                <button
                  type="button"
                  onClick={handleBack}
                  className="flex-1 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium rounded-full py-3 transition-colors"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleContinue}
                  className="flex-1 btn-primary py-3"
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
