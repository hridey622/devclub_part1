'use client';

import { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import Header from '@/components/Header';

export default function OnboardingProfilePicture() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSkip = () => {
    router.push('/auth/onboarding/location');
  };

  const handleContinue = () => {
    // In a real app, you would upload the file to your server or cloud storage
    // For demo purposes, we'll just proceed to the next step
    router.push('/auth/onboarding/location');
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <>
      <Header />
      <main className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container-custom max-w-xl mx-auto">
          <div className="card">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex justify-between items-center">
                <div className="flex-1">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '40%' }}></div>
                  </div>
                </div>
                <span className="ml-4 text-sm text-gray-600 dark:text-gray-400">Step 2 of 5</span>
              </div>
            </div>
            
            <div className="text-center mb-8">
              <h1 className="heading-lg text-gray-900 dark:text-white mb-2">Add a Profile Picture</h1>
              <p className="text-gray-600 dark:text-gray-300">
                Let others see who they'll be playing with
              </p>
            </div>

            <div className="space-y-8">
              {/* Profile Picture Upload Area */}
              <div 
                className={`border-2 border-dashed rounded-lg p-8 text-center ${
                  isDragging ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-300 dark:border-gray-700'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                {previewImage ? (
                  <div className="flex flex-col items-center">
                    <div className="relative w-40 h-40 rounded-full overflow-hidden mb-4">
                      <Image
                        src={previewImage}
                        alt="Profile preview"
                        fill
                        style={{ objectFit: 'cover' }}
                      />
                    </div>
                    <button 
                      type="button" 
                      className="text-blue-600 hover:text-blue-800 dark:text-blue-400 font-medium"
                      onClick={handleBrowseClick}
                    >
                      Choose a different photo
                    </button>
                  </div>
                ) : (
                  <div className="py-8">
                    <div className="flex justify-center mb-4">
                      <div className="w-20 h-20 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                        <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                      </div>
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      Drag and drop your photo here, or
                    </p>
                    <button
                      type="button"
                      className="btn-secondary text-sm px-4 py-2"
                      onClick={handleBrowseClick}
                    >
                      Browse Files
                    </button>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>

              <div className="flex space-x-4 pt-6">
                <button
                  type="button"
                  onClick={handleSkip}
                  className="flex-1 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium rounded-full py-3 transition-colors"
                >
                  Skip for Now
                </button>
                <button
                  type="button"
                  onClick={handleContinue}
                  className="flex-1 btn-primary py-3"
                  disabled={!previewImage}
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
