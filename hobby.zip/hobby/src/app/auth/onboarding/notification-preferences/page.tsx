'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';

export default function OnboardingNotifications() {
  const router = useRouter();
  const [allowNotifications, setAllowNotifications] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleBack = () => {
    router.push('/auth/onboarding/sports-skills');
  };

  const handleNotificationChoice = (allow: boolean) => {
    setAllowNotifications(allow);
    
    if (allow) {
      // In a real app, you would request notification permissions here
      // For demo, we'll simulate a request
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        router.push('/dashboard');
      }, 1500);
    } else {
      // Skip notifications
      router.push('/dashboard');
    }
  };

  return (
    <>
      <Header />
      <main className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container-custom max-w-xl mx-auto">
          <div className="card">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex justify-between items-center">
                <div className="flex-1">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '100%' }}></div>
                  </div>
                </div>
                <span className="ml-4 text-sm text-gray-600 dark:text-gray-400">Step 5 of 5</span>
              </div>
            </div>
            
            <div className="text-center mb-10">
              <div className="flex justify-center mb-6">
                <div className="w-20 h-20 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                  <svg className="w-10 h-10 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                </div>
              </div>
              
              <h1 className="heading-lg text-gray-900 dark:text-white mb-4">
                Enable Notifications
              </h1>
              <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-md mx-auto">
                Get notified about game invites, messages, and updates from players in your area
              </p>
              
              <div className="space-y-4">
                <button
                  type="button"
                  onClick={() => handleNotificationChoice(true)}
                  disabled={isLoading}
                  className="w-full btn-primary py-4 text-center flex items-center justify-center"
                >
                  {isLoading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Enabling Notifications...
                    </>
                  ) : (
                    'Yes, Enable Notifications'
                  )}
                </button>
                
                <button
                  type="button"
                  onClick={() => handleNotificationChoice(false)}
                  disabled={isLoading}
                  className="w-full border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium rounded-full py-4 transition-colors"
                >
                  Maybe Later
                </button>
              </div>
              
              <p className="mt-6 text-sm text-gray-500 dark:text-gray-400">
                You can always change your notification preferences in your account settings
              </p>
            </div>

            <div className="flex mt-6">
              <button
                type="button"
                onClick={handleBack}
                className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white font-medium"
              >
                ← Back
              </button>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
