'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';

export default function OnboardingLocation() {
  const router = useRouter();
  const [locationMethod, setLocationMethod] = useState<'auto' | 'manual'>('auto');
  const [manualLocation, setManualLocation] = useState('');
  const [locationPermission, setLocationPermission] = useState<'pending' | 'granted' | 'denied'>('pending');
  const [detectedLocation, setDetectedLocation] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleManualLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setManualLocation(e.target.value);
    if (error) setError('');
  };

  const handleAutoDetect = () => {
    setIsLoading(true);
    setError('');
    
    // Mock geolocation for demo purposes
    setTimeout(() => {
      // In a real app, you would use the browser's geolocation API:
      // navigator.geolocation.getCurrentPosition((position) => {...})
      
      // For demo, we'll just simulate a successful location detection
      setDetectedLocation('New Delhi, India');
      setLocationPermission('granted');
      setIsLoading(false);
    }, 1500);
  };

  const handleBack = () => {
    router.push('/auth/onboarding/profile-picture');
  };

  const validateForm = () => {
    if (locationMethod === 'manual' && !manualLocation.trim()) {
      setError('Please enter your city or postal code');
      return false;
    }
    return true;
  };

  const handleContinue = () => {
    if (!validateForm()) return;
    
    // In a real app, you would store the location data
    // For demo purposes, we'll just proceed to the next step
    router.push('/auth/onboarding/sports-skills');
  };

  return (
    <>
      <Header />
      <main className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container-custom max-w-xl mx-auto">
          <div className="card">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex justify-between items-center">
                <div className="flex-1">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                </div>
                <span className="ml-4 text-sm text-gray-600 dark:text-gray-400">Step 3 of 5</span>
              </div>
            </div>
            
            <div className="text-center mb-8">
              <h1 className="heading-lg text-gray-900 dark:text-white mb-2">Your Location</h1>
              <p className="text-gray-600 dark:text-gray-300">
                We'll use this to find players and games near you
              </p>
            </div>

            <div className="space-y-8">
              {/* Location Method Tabs */}
              <div className="flex mb-6 border-b border-gray-200 dark:border-gray-700">
                <button
                  className={`flex-1 py-3 font-medium text-center ${
                    locationMethod === 'auto'
                      ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-400 dark:border-blue-400'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                  onClick={() => setLocationMethod('auto')}
                >
                  Auto-Detect
                </button>
                <button
                  className={`flex-1 py-3 font-medium text-center ${
                    locationMethod === 'manual'
                      ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-400 dark:border-blue-400'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                  onClick={() => setLocationMethod('manual')}
                >
                  Enter Manually
                </button>
              </div>

              {/* Auto-Detect Location */}
              {locationMethod === 'auto' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-center mb-4">
                    <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                      <svg className="w-8 h-8 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </div>
                  </div>
                  
                  {locationPermission === 'pending' && (
                    <div className="text-center">
                      <p className="text-gray-600 dark:text-gray-300 mb-4">
                        Allow Hobby to access your location to find players and courts nearby
                      </p>
                      <button
                        type="button"
                        onClick={handleAutoDetect}
                        className="btn-primary py-3 px-6 inline-flex items-center"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <>
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Detecting...
                          </>
                        ) : (
                          'Detect My Location'
                        )}
                      </button>
                    </div>
                  )}
                  
                  {locationPermission === 'granted' && (
                    <div className="text-center">
                      <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 mb-4">
                        <div className="flex">
                          <svg className="h-5 w-5 text-green-500 dark:text-green-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                          </svg>
                          <p className="text-green-700 dark:text-green-300">
                            We found your location: <strong>{detectedLocation}</strong>
                          </p>
                        </div>
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 mb-4">
                        We'll use this to show you players and games nearby
                      </p>
                    </div>
                  )}
                  
                  {locationPermission === 'denied' && (
                    <div className="text-center">
                      <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 mb-4">
                        <div className="flex">
                          <svg className="h-5 w-5 text-red-500 dark:text-red-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                          </svg>
                          <p className="text-red-700 dark:text-red-300">
                            Location access was denied. Please try entering your location manually.
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setLocationMethod('manual')}
                        className="text-blue-600 hover:text-blue-800 dark:text-blue-400 font-medium"
                      >
                        Enter location manually
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Manual Location Entry */}
              {locationMethod === 'manual' && (
                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    City or Postal Code
                  </label>
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={manualLocation}
                    onChange={handleManualLocationChange}
                    className={`w-full px-4 py-3 rounded-lg border ${
                      error ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                    } focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white`}
                    placeholder="e.g., New Delhi or 110001"
                  />
                  {error && (
                    <p className="mt-1 text-sm text-red-600">{error}</p>
                  )}
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    We'll use this to show you players and games in your area
                  </p>
                </div>
              )}

              <div className="flex space-x-4 pt-6">
                <button
                  type="button"
                  onClick={handleBack}
                  className="flex-1 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium rounded-full py-3 transition-colors"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleContinue}
                  className="flex-1 btn-primary py-3"
                  disabled={locationMethod === 'auto' && locationPermission === 'pending'}
                >
                  Continue
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
