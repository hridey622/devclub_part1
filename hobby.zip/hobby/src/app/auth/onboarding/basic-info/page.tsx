'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';

export default function OnboardingBasicInfo() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    birthdate: '',
    gender: '',
  });
  const [errors, setErrors] = useState({
    birthdate: '',
    gender: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    
    // Clear error when user makes a selection
    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = { ...errors };

    // Birthdate validation
    if (!formData.birthdate) {
      newErrors.birthdate = 'Birth date is required';
      isValid = false;
    }

    // Gender validation
    if (!formData.gender) {
      newErrors.gender = 'Please select a gender';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    // In a real app, you would likely store this data in a context or state management solution
    // For simplicity, we'll just move to the next step
    router.push('/auth/onboarding/profile-picture');
  };

  // Calculate max date (must be at least 13 years old)
  const maxDate = new Date();
  maxDate.setFullYear(maxDate.getFullYear() - 13);
  const maxDateStr = maxDate.toISOString().split('T')[0];

  return (
    <>
      <Header />
      <main className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container-custom max-w-xl mx-auto">
          <div className="card">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex justify-between items-center">
                <div className="flex-1">
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '20%' }}></div>
                  </div>
                </div>
                <span className="ml-4 text-sm text-gray-600 dark:text-gray-400">Step 1 of 5</span>
              </div>
            </div>
            
            <div className="text-center mb-8">
              <h1 className="heading-lg text-gray-900 dark:text-white mb-2">Basic Information</h1>
              <p className="text-gray-600 dark:text-gray-300">
                Tell us a bit about yourself
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Birthdate Field */}
              <div>
                <label htmlFor="birthdate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Date of Birth
                </label>
                <input
                  type="date"
                  id="birthdate"
                  name="birthdate"
                  max={maxDateStr}
                  value={formData.birthdate}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 rounded-lg border ${
                    errors.birthdate ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                  } focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white`}
                />
                {errors.birthdate && (
                  <p className="mt-1 text-sm text-red-600">{errors.birthdate}</p>
                )}
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  You must be at least 13 years old to use Hobby.
                </p>
              </div>

              {/* Gender Field */}
              <div>
                <label htmlFor="gender" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Gender
                </label>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 rounded-lg border ${
                    errors.gender ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                  } focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white`}
                >
                  <option value="" disabled>Select your gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                  <option value="prefer-not-to-say">Prefer not to say</option>
                </select>
                {errors.gender && (
                  <p className="mt-1 text-sm text-red-600">{errors.gender}</p>
                )}
              </div>

              <div className="flex space-x-4 pt-6">
                {/* For the first step, we don't have a back button */}
                <button
                  type="submit"
                  className="flex-1 btn-primary py-3"
                >
                  Continue
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </>
  );
}
