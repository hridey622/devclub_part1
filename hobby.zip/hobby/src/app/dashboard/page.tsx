'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('home');
  
  // Sample data for demonstration purposes
  const upcomingGames = [
    { id: 1, sport: 'Cricket', date: 'Tomorrow, 5:00 PM', location: 'Green Park', players: '8/11' },
    { id: 2, sport: 'Football', date: 'Apr 5, 6:30 PM', location: 'City Stadium', players: '12/14' },
  ];

  const suggestedPlayers = [
    { id: 1, name: 'Rahul Kumar', sport: 'Cricket', skill: 'Intermediate', distance: '3.2 km' },
    { id: 2, name: 'Ananya Singh', sport: 'Tennis', skill: 'Advanced', distance: '1.5 km' },
    { id: 3, name: 'Vikram Patel', sport: 'Football', skill: 'Intermediate', distance: '4.7 km' },
  ];

  const nearbyCourts = [
    { id: 1, name: 'Green Park Cricket Ground', sport: 'Cricket', distance: '2.1 km', rating: 4.3 },
    { id: 2, name: 'City Sports Club', sport: 'Multiple', distance: '3.5 km', rating: 4.7 },
    { id: 3, name: 'Downtown Badminton Center', sport: 'Badminton', distance: '1.8 km', rating: 4.1 },
  ];
  
  const recentNotifications = [
    { id: 1, type: 'invite', text: 'Rahul invited you to a Cricket match', time: '2 hours ago' },
    { id: 2, type: 'message', text: 'New message from Ananya', time: '5 hours ago' },
    { id: 3, type: 'game', text: 'Cricket game on Apr 2 has been confirmed', time: '1 day ago' },
  ];

  // Dashboard navigation component
  const DashboardNavigation = () => (
    <div className="bg-white dark:bg-gray-800 shadow-sm border-t border-gray-200 dark:border-gray-700 fixed bottom-0 left-0 right-0 z-50 md:hidden">
      <div className="flex justify-around">
        <button 
          className={`flex flex-col items-center py-3 px-4 ${activeTab === 'home' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'}`}
          onClick={() => setActiveTab('home')}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
          </svg>
          <span className="text-xs mt-1">Home</span>
        </button>
        <button 
          className={`flex flex-col items-center py-3 px-4 ${activeTab === 'games' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'}`}
          onClick={() => setActiveTab('games')}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <span className="text-xs mt-1">Games</span>
        </button>
        <button 
          className={`flex flex-col items-center py-3 px-4 ${activeTab === 'players' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'}`}
          onClick={() => setActiveTab('players')}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <span className="text-xs mt-1">Players</span>
        </button>
        <button 
          className={`flex flex-col items-center py-3 px-4 ${activeTab === 'messages' ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'}`}
          onClick={() => setActiveTab('messages')}
        >
          <div className="relative">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <span className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
          </div>
          <span className="text-xs mt-1">Messages</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      <Header />
      
      <main className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 pt-6 pb-20 md:pb-6">
        <div className="container-custom">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="heading-lg text-gray-900 dark:text-white mb-2">
              Welcome, John!
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              Here's what's happening around you
            </p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <Link href="/create-game" className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl p-4 flex flex-col items-center justify-center text-center transition-colors">
              <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              <span className="font-medium">Create Game</span>
            </Link>
            <Link href="/find-players" className="bg-green-600 hover:bg-green-700 text-white rounded-xl p-4 flex flex-col items-center justify-center text-center transition-colors">
              <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <span className="font-medium">Find Players</span>
            </Link>
          </div>

          {/* Main Dashboard Content */}
          <div className="grid md:grid-cols-3 gap-6">
            {/* Upcoming Games */}
            <div className="card">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Upcoming Games</h2>
                <Link href="/games" className="text-blue-600 text-sm hover:text-blue-800 dark:text-blue-400">
                  See All
                </Link>
              </div>
              
              {upcomingGames.length > 0 ? (
                <div className="space-y-4">
                  {upcomingGames.map(game => (
                    <div key={game.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                      <div className="flex justify-between mb-2">
                        <span className="font-medium">{game.sport}</span>
                        <span className="text-sm text-gray-600 dark:text-gray-400">{game.date}</span>
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        {game.location}
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          Players: {game.players}
                        </span>
                        <Link href={`/games/${game.id}`} className="text-blue-600 text-sm hover:text-blue-800 dark:text-blue-400">
                          Details
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="bg-gray-100 dark:bg-gray-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No Upcoming Games</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    You don't have any games scheduled yet
                  </p>
                  <Link href="/find-games" className="btn-primary text-sm py-2 px-4">
                    Find Games
                  </Link>
                </div>
              )}
            </div>

            {/* Suggested Players */}
            <div className="card">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Players Near You</h2>
                <Link href="/players" className="text-blue-600 text-sm hover:text-blue-800 dark:text-blue-400">
                  See All
                </Link>
              </div>
              
              <div className="space-y-4">
                {suggestedPlayers.map(player => (
                  <div key={player.id} className="flex items-center border border-gray-200 dark:border-gray-700 rounded-lg p-3">
                    <div className="w-10 h-10 bg-gray-200 dark:bg-gray-700 rounded-full flex-shrink-0 flex items-center justify-center mr-3">
                      <svg className="w-6 h-6 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{player.name}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                        {player.sport} • {player.skill} • {player.distance}
                      </p>
                    </div>
                    <Link href={`/players/${player.id}`} className="text-blue-600 text-sm hover:text-blue-800 dark:text-blue-400 ml-2">
                      View
                    </Link>
                  </div>
                ))}
              </div>
            </div>

            {/* Split third column into two sections */}
            <div className="space-y-6">
              {/* Nearby Courts */}
              <div className="card">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Nearby Courts</h2>
                  <Link href="/venues" className="text-blue-600 text-sm hover:text-blue-800 dark:text-blue-400">
                    See All
                  </Link>
                </div>
                
                <div className="space-y-3">
                  {nearbyCourts.map(court => (
                    <div key={court.id} className="flex justify-between border border-gray-200 dark:border-gray-700 rounded-lg p-3">
                      <div>
                        <p className="font-medium">{court.name}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {court.sport} • {court.distance}
                        </p>
                      </div>
                      <div className="text-sm text-yellow-500 flex items-center">
                        <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        {court.rating}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Notifications */}
              <div className="card">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Notifications</h2>
                  <button className="text-blue-600 text-sm hover:text-blue-800 dark:text-blue-400">
                    Mark All as Read
                  </button>
                </div>
                
                <div className="space-y-3">
                  {recentNotifications.map(notification => (
                    <div key={notification.id} className="flex items-start p-3 border-b border-gray-200 dark:border-gray-700 last:border-0">
                      <div className={`p-2 rounded-full mr-3 flex-shrink-0 ${
                        notification.type === 'invite' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-400' :
                        notification.type === 'message' ? 'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400' :
                        'bg-amber-100 text-amber-600 dark:bg-amber-900 dark:text-amber-400'
                      }`}>
                        {notification.type === 'invite' && (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                          </svg>
                        )}
                        {notification.type === 'message' && (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                          </svg>
                        )}
                        {notification.type === 'game' && (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">
                          {notification.text}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {notification.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <DashboardNavigation />
      <Footer />
    </>
  );
}
